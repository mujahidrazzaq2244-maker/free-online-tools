/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { GeneratedContent } from "../types";
import { 
  Eye, 
  Code, 
  FileEdit, 
  Copy, 
  Check, 
  Plus, 
  Trash2,
  Download, 
  Calendar, 
  User, 
  Tag as TagIcon,
  Layout,
  ExternalLink,
  ChevronDown
} from "lucide-react";

interface EditorSimulatorProps {
  result: GeneratedContent;
  onChange: (updated: GeneratedContent) => void;
}

type TabType = "gutenberg" | "visual" | "raw";

export default function EditorSimulator({ result, onChange }: EditorSimulatorProps) {
  const [activeTab, setActiveTab] = useState<TabType>("gutenberg");
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [newTag, setNewTag] = useState("");
  const [featuredImage, setFeaturedImage] = useState<string>(
    "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&auto=format&fit=crop&q=60"
  );

  const imagesPreset = [
    { name: "Workspace/Laptop", url: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&auto=format&fit=crop&q=60" },
    { name: "Coffee & Code", url: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=60" },
    { name: "Digital Growth/Analytics", url: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=60" },
    { name: "Writing/Creativity", url: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&auto=format&fit=crop&q=60" }
  ];

  const handleCopy = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleAddField = (field: keyof GeneratedContent, value: any) => {
    onChange({ ...result, [field]: value });
  };

  const inlineUpdateField = (field: keyof GeneratedContent, value: any) => {
    onChange({ ...result, [field]: value });
  };

  const handleAddTag = () => {
    if (newTag.trim() && !result.tags.includes(newTag.trim())) {
      const updatedTags = [...result.tags, newTag.trim()].slice(0, 8); // Max 8 tags
      inlineUpdateField("tags", updatedTags);
      setNewTag("");
    }
  };

  const handleRemoveTag = (indexToRemove: number) => {
    const updatedTags = result.tags.filter((_, idx) => idx !== indexToRemove);
    inlineUpdateField("tags", updatedTags);
  };

  // Convert markdown body to clean mock HTML tags for raw preview representation
  const getHtmlRepresentation = () => {
    // A simplified converter to demonstrate realistic copyable HTML content
    let htmlOutput = `<!-- WordPress SEO Article -->\n`;
    htmlOutput += `<h1>${result.title}</h1>\n\n`;
    
    const lines = result.content.split("\n");
    let inList = false;

    lines.forEach((line) => {
      const cleanLine = line.trim();
      if (cleanLine.startsWith("### ")) {
        if (inList) { htmlOutput += "</ul>\n"; inList = false; }
        htmlOutput += `<h3>${cleanLine.slice(4)}</h3>\n`;
      } else if (cleanLine.startsWith("## ")) {
        if (inList) { htmlOutput += "</ul>\n"; inList = false; }
        htmlOutput += `<h2>${cleanLine.slice(3)}</h2>\n`;
      } else if (cleanLine.startsWith("* ") || cleanLine.startsWith("- ")) {
        if (!inList) { htmlOutput += "<ul>\n"; inList = true; }
        htmlOutput += `  <li>${cleanLine.slice(2)}</li>\n`;
      } else if (cleanLine.match(/^\d+\.\s/)) {
        if (inList) { htmlOutput += "</ul>\n"; inList = false; }
        htmlOutput += `  <li>${cleanLine.replace(/^\d+\.\s/, "")}</li>\n`;
      } else if (cleanLine.length > 0) {
        if (inList) { htmlOutput += "</ul>\n"; inList = false; }
        htmlOutput += `<p>${cleanLine}</p>\n`;
      }
    });

    if (inList) { htmlOutput += "</ul>\n"; }
    
    if (result.callToAction) {
      htmlOutput += `\n<!-- Call To Action -->\n`;
      htmlOutput += `<div class="wp-block-buttons aligncenter">\n`;
      htmlOutput += `  <div class="wp-block-button">\n`;
      htmlOutput += `    <a class="wp-block-button__link has-background has-vivid-cyan-blue-background-color" href="#">${result.callToAction}</a>\n`;
      htmlOutput += `  </div>\n</div>\n`;
    }

    return htmlOutput;
  };

  const downloadMarkdown = () => {
    const header = `---\ntitle: ${result.title}\nmeta_description: ${result.metaDescription}\ntags: ${result.tags.join(", ")}\n---\n\n`;
    const fullBody = header + result.content + `\n\n---\n**Call To Action:**\n${result.callToAction}`;
    const blob = new Blob([fullBody], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${result.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const downloadWordPressJson = () => {
    // Generate a beautiful JSON file custom tailored to be copy-pasted or imported directly
    const data = {
      title: result.title,
      status: "draft",
      content: getHtmlRepresentation(),
      excerpt: result.metaDescription,
      tags: result.tags,
      meta: {
        _yoast_wpseo_metadesc: result.metaDescription,
        _yoast_wpseo_title: result.title
      }
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${result.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-wp-import.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden flex flex-col h-full shadow-xs" id="editor-simulator">
      {/* Simulator Toolbar Header */}
      <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50 flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 mr-3">
            <span className="w-3 h-3 rounded-full bg-red-400"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-400"></span>
            <span className="w-3 h-3 rounded-full bg-green-400"></span>
          </div>
          <span className="text-sm font-semibold tracking-wide text-gray-400 uppercase flex items-center gap-1.5">
            <Layout className="w-4 h-4 text-blue-500" /> WP Workspace
          </span>
        </div>

        {/* View Mode Tabs */}
        <div className="flex bg-gray-100 p-1 rounded-xl">
          <button
            id="tab-gutenberg"
            onClick={() => setActiveTab("gutenberg")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "gutenberg"
                ? "bg-white text-gray-900 shadow-xs"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <FileEdit className="w-3.5 h-3.5 text-indigo-500" />
            <span>Classic Word Editor</span>
          </button>
          
          <button
            id="tab-visual"
            onClick={() => setActiveTab("visual")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "visual"
                ? "bg-white text-gray-900 shadow-xs"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-indigo-500" />
            <span>Public Live Preview</span>
          </button>

          <button
            id="tab-raw"
            onClick={() => setActiveTab("raw")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "raw"
                ? "bg-white text-gray-900 shadow-xs"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Code className="w-3.5 h-3.5 text-indigo-500" />
            <span>Raw HTML / Source</span>
          </button>
        </div>

        {/* Download Drops */}
        <div className="flex gap-2">
          <button
            onClick={downloadMarkdown}
            id="download-md-btn"
            className="p-2 text-xs font-medium bg-white hover:bg-gray-50 text-gray-600 rounded-xl border border-gray-200 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Download Markdown"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Markdown</span>
          </button>
          <button
            onClick={downloadWordPressJson}
            id="download-wp-json-btn"
            className="p-2 text-xs font-medium bg-white hover:bg-gray-50 text-gray-600 rounded-xl border border-gray-200 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Export WP Gutenberg Schema"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export WP JSON</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Frame */}
      <div className="flex-1 overflow-y-auto p-6 bg-white min-h-[450px]">
        
        {/* TAB 1: EDITABLE GUTENBERG SIMULATOR */}
        {activeTab === "gutenberg" && (
          <div className="max-w-3xl mx-auto space-y-6" id="gutenberg-editor-view">
            {/* WordPress Header Elements */}
            <div className="border border-yellow-200 bg-yellow-50/50 rounded-xl p-4 flex items-start gap-3">
              <span className="text-lg">💡</span>
              <div className="text-xs text-yellow-800 leading-relaxed font-sans">
                <span className="font-semibold block mb-0.5">Interactive WordPress WorkSpace</span>
                You can directly edit the generative draft below! All revisions will immediately update the SEO audits, metrics indicators, keyword counts, and final exports on your right sidebar panel.
              </div>
            </div>

            {/* Post Title Field */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block px-1">WordPress Title (H1)</label>
              <textarea
                id="edit-title-field"
                value={result.title}
                onChange={(e) => inlineUpdateField("title", e.target.value)}
                placeholder="Post Title..."
                rows={1}
                className="w-full text-2xl sm:text-3xl font-bold font-sans text-gray-900 border-b border-gray-100 hover:border-gray-200 focus:border-blue-500 focus:outline-hidden py-2"
                style={{ resize: "none" }}
              />
            </div>

            {/* Content Body Editor */}
            <div className="space-y-1">
              <div className="flex items-center justify-between block px-1 mb-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Article Body (Markdown)</label>
                <span className="text-[10px] font-mono text-gray-400">Use Markdown (##, ###) for formatting</span>
              </div>
              <textarea
                id="edit-content-field"
                value={result.content}
                onChange={(e) => inlineUpdateField("content", e.target.value)}
                placeholder="Write article..."
                rows={15}
                className="w-full text-sm font-sans text-gray-800 p-4 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-3 focus:ring-blue-100 focus:outline-hidden leading-relaxed h-[420px]"
              />
            </div>

            {/* Call To Action Block */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block px-1">WordPress Button / CTA Block</label>
              <input
                id="edit-cta-field"
                type="text"
                value={result.callToAction}
                onChange={(e) => inlineUpdateField("callToAction", e.target.value)}
                placeholder="Call to Action (e.g., Claim Your Remote Guide Free Now!)"
                className="w-full p-3 text-sm text-blue-700 bg-blue-50/20 border border-blue-200 hover:border-blue-300 focus:border-blue-500 rounded-xl font-medium focus:outline-hidden"
              />
            </div>

            {/* Meta Description */}
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 space-y-2">
              <div className="flex justify-between items-center px-1">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Yoast SEO / RankMath Meta Description</label>
                <span className={`text-xs font-semibold ${
                  result.metaDescription.length >= 140 && result.metaDescription.length <= 165 
                    ? "text-emerald-600" 
                    : "text-amber-500"
                }`}>
                  {result.metaDescription.length} / 160 chars
                </span>
              </div>
              <textarea
                id="edit-meta-field"
                value={result.metaDescription}
                onChange={(e) => inlineUpdateField("metaDescription", e.target.value)}
                className="w-full p-3 text-xs text-gray-600 bg-white border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-hidden leading-relaxed"
                rows={2}
                placeholder="Provide short meta synopsis..."
              />
            </div>

            {/* Tag Manager and Featured Image selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* Tags Section */}
              <div className="border border-gray-100 rounded-xl p-4 space-y-3">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
                  <TagIcon className="w-3.5 h-3.5 text-blue-500" /> Tag Manager
                </h4>
                
                {/* Visual Tag Badges */}
                <div className="flex flex-wrap gap-1.5">
                  {result.tags.map((tag, idx) => (
                    <span 
                      key={tag + idx} 
                      className="px-2 py-1 text-xs bg-gray-150 text-gray-700 font-medium rounded-md flex items-center gap-1.5"
                    >
                      <span>#{tag}</span>
                      <button 
                        type="button" 
                        onClick={() => handleRemoveTag(idx)}
                        className="text-gray-400 hover:text-red-500 transition-all font-bold cursor-pointer"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  {result.tags.length === 0 && (
                    <span className="text-xs text-gray-400 italic">No tags. Enter tags below.</span>
                  )}
                </div>

                {/* Add Tag row */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAddTag()}
                    placeholder="Add tag (e.g. tutorials)"
                    className="flex-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="p-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Featured Image Selector */}
              <div className="border border-gray-100 rounded-xl p-4 space-y-3">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Featured Image Preset</h4>
                <div className="aspect-video w-full rounded-lg overflow-hidden border border-gray-100 bg-gray-50 relative group">
                  <img src={featuredImage} alt="Featured" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-2 opacity-0 group-hover:opacity-100 transition-all duration-200 text-white text-[10px] font-sans">
                    Optionally select a mood representation image below
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-1.5">
                  {imagesPreset.map((img) => (
                    <button
                      key={img.name}
                      type="button"
                      onClick={() => setFeaturedImage(img.url)}
                      className={`h-10 rounded-sm overflow-hidden border-2 transition-all cursor-pointer ${
                        featuredImage === img.url ? "border-blue-500 scale-95" : "border-transparent hover:border-gray-300"
                      }`}
                      title={img.name}
                    >
                      <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: RICH BLOG VISUAL PREVIEW */}
        {activeTab === "visual" && (
          <article className="max-w-2xl mx-auto space-y-4 font-sans" id="blog-visual-view">
            
            {/* Header category badge / date row */}
            <div className="flex items-center gap-3 text-xs text-gray-400 font-sans pb-1 border-b border-gray-100">
              <span className="font-semibold text-blue-600 uppercase tracking-wider">Uncategorized Article</span>
              <span>•</span>
              <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> June 3, 2026</span>
              <span>•</span>
              <span className="flex items-center gap-1"><User className="w-3 h-3" /> Digital Marketer Workspace</span>
            </div>

            {/* SEO Title */}
            <h1 className="text-3xl sm:text-4xl font-bold font-sans tracking-tight text-gray-900 leading-tight">
              {result.title || "Untitled Blog Post"}
            </h1>

            {/* Featured Image decoration */}
            {featuredImage && (
              <div className="w-full h-56 sm:h-72 rounded-2xl overflow-hidden border border-gray-100 shadow-xs my-4">
                <img src={featuredImage} alt="Featured representation" className="w-full h-full object-cover" />
              </div>
            )}

            {/* Article Content styled beautifully as proper markdown typography. Oh yes! */}
            <div className="prose prose-blue max-w-none text-gray-800 leading-relaxed font-sans prose-headings:font-bold prose-h2:text-xl prose-h2:mt-6 prose-h2:mb-3 prose-p:mb-4 prose-ul:list-disc prose-ul:pl-5 prose-ul:mb-4">
              <ReactMarkdown>{result.content}</ReactMarkdown>
            </div>

            {/* CTA Display */}
            {result.callToAction && (
              <div className="my-8 p-6 rounded-2xl bg-gradient-to-tr from-blue-50 via-indigo-50/30 to-purple-50 border border-blue-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-center sm:text-left">
                  <span className="text-xs font-semibold uppercase tracking-wider text-blue-600">Special Promotion Offer</span>
                  <p className="text-sm font-semibold text-gray-800">{result.callToAction}</p>
                </div>
                <a 
                  href="#cta" 
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer hover:shadow-lg hover:scale-[1.02]"
                >
                  <span>Learn More</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            )}

            {/* Footer Tags representation */}
            {result.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-6 border-t border-gray-100">
                <span className="text-xs font-bold text-gray-400 self-center">Tags:</span>
                {result.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-medium rounded-full transition-all cursor-pointer">
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </article>
        )}

        {/* TAB 3: RAW HTML CODE PREVIEW */}
        {activeTab === "raw" && (
          <div className="space-y-4" id="html-raw-view">
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-gray-500 font-mono">WordPress ready-to-publish raw HTML block code</span>
                <button
                  onClick={() => handleCopy(getHtmlRepresentation(), "full-html")}
                  className="px-3 py-1.5 text-xs bg-white border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer font-medium"
                >
                  {copiedSection === "full-html" ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-green-500" />
                      <span className="text-green-600 font-sans">Copied code!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="font-sans">Copy Code</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 bg-gray-900 border border-gray-900 rounded-lg overflow-x-auto text-[11px] font-mono text-gray-300 leading-relaxed max-h-[380px]">
                {getHtmlRepresentation()}
              </pre>
            </div>

            {/* Separated sections for single copy-paste access */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-gray-100 rounded-xl space-y-1 flex flex-col justify-between">
                <div>
                  <h5 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">SEO Blog Title</h5>
                  <p className="text-sm font-sans font-semibold text-gray-800 break-words">{result.title}</p>
                </div>
                <button
                  onClick={() => handleCopy(result.title, "partial-title")}
                  className="px-2.5 py-1 text-xs text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-1.5 cursor-pointer mt-3 w-fit transition-all font-medium"
                >
                  {copiedSection === "partial-title" ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedSection === "partial-title" ? "Copied!" : "Copy Title"}</span>
                </button>
              </div>

              <div className="p-4 border border-gray-100 rounded-xl space-y-1 flex flex-col justify-between">
                <div>
                  <h5 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Meta Synopsis Description</h5>
                  <p className="text-xs font-sans text-gray-600 italic break-words">"{result.metaDescription}"</p>
                </div>
                <button
                  onClick={() => handleCopy(result.metaDescription, "partial-meta")}
                  className="px-2.5 py-1 text-xs text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-1.5 cursor-pointer mt-3 w-fit transition-all font-medium"
                >
                  {copiedSection === "partial-meta" ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedSection === "partial-meta" ? "Copied!" : "Copy Description"}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
