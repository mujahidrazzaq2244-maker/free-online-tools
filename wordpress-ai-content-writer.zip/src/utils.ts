/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SEOMetrics {
  wordCount: number;
  charCount: number;
  readingTime: number; // in minutes
  keywordMatches: { keyword: string; count: number }[];
  seoScore: number; // out of 100
  checklist: { id: string; label: string; passed: boolean; tip: string }[];
}

export function parseKeywords(keywordInput: string): string[] {
  if (!keywordInput) return [];
  return keywordInput
    .split(",")
    .map((kw) => kw.trim())
    .filter((kw) => kw.length > 0);
}

export function calculateMetrics(
  title: string,
  content: string,
  metaDescription: string,
  keywords: string[]
): SEOMetrics {
  const cleanBody = content || "";
  const cleanTitle = title || "";
  const cleanMeta = metaDescription || "";

  // 1. Word count
  const words = cleanBody.trim().split(/\s+/).filter((w) => w.length > 0);
  const wordCount = words.length;

  // 2. Character count
  const charCount = cleanBody.length;

  // 3. Reading time (average 220 words per minute)
  const readingTime = Math.max(1, Math.ceil(wordCount / 220));

  // 4. Keyword matches
  const keywordMatches = keywords.map((kw) => {
    const regex = new RegExp(`\\b${kw.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")}\\b`, "gi");
    const count = (cleanBody.match(regex) || []).length + (cleanTitle.match(regex) || []).length;
    return { keyword: kw, count };
  });

  // 5. Checklist & SEO Score calculation
  const checklist = [
    {
      id: "title-length",
      label: "Compelling Title Length",
      passed: cleanTitle.length >= 30 && cleanTitle.length <= 70,
      tip: "Title should be between 30 and 70 characters for best Google previews.",
    },
    {
      id: "keyword-in-title",
      label: "Keyword in Title",
      passed: keywords.length > 0 ? keywords.some((kw) => cleanTitle.toLowerCase().includes(kw.toLowerCase())) : true,
      tip: "Try to place one of your primary keywords inside the main heading/title.",
    },
    {
      id: "meta-length",
      label: "Meta Description Length",
      passed: cleanMeta.length >= 140 && cleanMeta.length <= 165,
      tip: "Google truncates description tags after ~160 characters. Goal is 150-160.",
    },
    {
      id: "content-length",
      label: "Min Word Count Threshold",
      passed: wordCount >= 350,
      tip: "We recommend at least 350–500 words for structural search index depth.",
    },
    {
      id: "has-subheadings",
      label: "Logical Subheadings (H2/H3)",
      passed: /##\s+/g.test(cleanBody),
      tip: "Use Markdown headers (##) to divide contents and make it scannable.",
    },
    {
      id: "has-bullet-points",
      label: "Readable Bullet Points or Lists",
      passed: /(\*|-|\d\.)\s+/g.test(cleanBody),
      tip: "Break up long texts by including bullet points or numbered checklists.",
    },
    {
      id: "keyword-presence",
      label: "Natural Keyword Density",
      passed: keywords.length > 0 ? keywordMatches.some((kw) => kw.count >= 2) : true,
      tip: "Integrate core keywords at least 2 or 3 times in headings and body copy.",
    },
  ];

  // Calculate percentage of passed checks
  const passedCount = checklist.filter((item) => item.passed).length;
  const seoScore = Math.round((passedCount / checklist.length) * 100);

  return {
    wordCount,
    charCount,
    readingTime,
    keywordMatches,
    seoScore,
    checklist,
  };
}
