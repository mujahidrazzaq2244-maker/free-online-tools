/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GeneratorParams {
  contentType: string;
  topic: string;
  audience: string;
  tone: string;
  purpose: string;
  keywords: string;
  language: string;
  length: string;
}

export interface GeneratedContent {
  title: string;
  content: string; // Markdown formatted content
  metaDescription: string;
  tags: string[];
  callToAction: string;
}

export interface HistoryItem {
  id: string;
  timestamp: string;
  params: GeneratorParams;
  result: GeneratedContent;
}
