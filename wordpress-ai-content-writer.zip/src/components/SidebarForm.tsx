/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { GeneratorParams } from "../types";
import { 
  FileText, 
  Sparkles, 
  Type, 
  Target, 
  Globe, 
  Hash, 
  ChevronRight, 
  RotateCcw,
  BookOpen
} from "lucide-react";

interface SidebarFormProps {
  onGenerate: (params: GeneratorParams) => void;
  loading: boolean;
  initialParams?: GeneratorParams;
}

const CONTENT_TYPES = [
  { value: "Blog Post", label: "Blog Article", desc: "SEO-optimized informative posts" },
  { value: "Product Description", label: "Product Listing", desc: "Compelling descriptions that sell" },
  { value: "Landing Page Copy", label: "Landing Page Pitch", desc: "High-conversion web copy" },
  { value: "Email Newsletter", label: "Newsletter / Broadcast", desc: "Nurture subscriber relationships" },
  { value: "Product Review", label: "Affiliate Review", desc: "Trust-building product critiques" },
  { value: "FAQ Section", label: "WordPress FAQ Accordion", desc: "Structured question & answers" },
  { value: "How-To Guide", label: "Technical Tutorial", desc: "Clear step-by-step documentation" }
];

const TONES = [
  { value: "Professional & Authoritative", label: "Professional & Authoritative" },
  { value: "Friendly & Conversational", label: "Friendly & Conversational" },
  { value: "Persuasive & Sales-Oriented", label: "Persuasive & Sales-Oriented" },
  { value: "Informative & Educational", label: "Informative & Educational" },
  { value: "Bold & Inspirational", label: "Bold & Inspirational" },
  { value: "Casual & Witty", label: "Casual & Witty" },
  { value: "Empathetic & Warm", label: "Empathetic & Warm" }
];

const PURPOSES = [
  { value: "Increase SEO Organic Rankings", label: "SEO Rankings & Traffic" },
  { value: "Drive Sales & Product Conversions", label: "Sales & Conversions" },
  { value: "Generate High-Quality Leads", label: "Lead Generation" },
  { value: "Educate & Build Industry Authority", label: "Brand Authority" },
  { value: "Encourage Social Shares & Buzz", label: "Viral Engagement" }
];

const LANGUAGES = [
  { value: "English", label: "English 🇺🇸" },
  { value: "Spanish (Español)", label: "Spanish (Español) 🇪🇸" },
  { value: "French (Français)", label: "French (Français) 🇫🇷" },
  { value: "German (Deutsch)", label: "German (Deutsch) 🇩🇪" },
  { value: "Italian (Italiano)", label: "Italian (Italiano) 🇮🇹" },
  { value: "Portuguese (Português)", label: "Portuguese (Português) 🇵🇹" },
  { value: "Dutch (Nederlands)", label: "Dutch (Nederlands) 🇳🇱" },
  { value: "Hindi (हिन्दी)", label: "Hindi (हिन्दी) 🇮🇳" },
  { value: "Japanese (日本語)", label: "Japanese (日本語) 🇯🇵" }
];

const LENGTHS = [
  { value: "Short (~500 words)", label: "Short (~500 words)" },
  { value: "Medium (~1000 words)", label: "Medium (~1000 words)" },
  { value: "Long (~1500+ words)", label: "Long (~1500+ words)" }
];

export default function SidebarForm({ onGenerate, loading, initialParams }: SidebarFormProps) {
  const [params, setParams] = useState<GeneratorParams>(
    initialParams || {
      contentType: "Blog Post",
      topic: "",
      audience: "",
      tone: "Friendly & Conversational",
      purpose: "Increase SEO Organic Rankings",
      keywords: "",
      language: "English",
      length: "Medium (~1000 words)",
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!params.topic.trim()) return;
    onGenerate(params);
  };

  const handleReset = () => {
    setParams({
      contentType: "Blog Post",
      topic: "",
      audience: "",
      tone: "Friendly & Conversational",
      purpose: "Increase SEO Organic Rankings",
      keywords: "",
      language: "English",
      length: "Medium (~1000 words)",
    });
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6" id="generator-form">
      {/* Content Type Selector */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2.5 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5 text-blue-500" /> Content Type
        </label>
        <div className="grid grid-cols-1 gap-2">
          {CONTENT_TYPES.map((type) => (
            <button
              key={type.value}
              type="button"
              id={`content-type-${type.value.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setParams({ ...params, contentType: type.value })}
              className={`p-3 text-left rounded-xl border transition-all duration-200 cursor-pointer flex flex-col ${
                params.contentType === type.value
                  ? "border-blue-600 bg-blue-50/50 shadow-xs"
                  : "border-gray-200 hover:border-gray-300 hover:bg-gray-50/50"
              }`}
            >
              <span className={`text-sm font-medium ${params.contentType === type.value ? "text-blue-700" : "text-gray-700"}`}>
                {type.label}
              </span>
              <span className="text-xs text-gray-400 mt-0.5 font-normal leading-normal">{type.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Topic input */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-yellow-500" /> Core Topic or Title Pitch
        </label>
        <textarea
          id="topic-input"
          required
          rows={3}
          value={params.topic}
          onChange={(e) => setParams({ ...params, topic: e.target.value })}
          placeholder="e.g. 10 Remote Work Productivity Hacks for Developers or Ultimate travel guide to Kyoto on a student budget"
          className="w-full p-3.5 rounded-xl border border-gray-200 bg-white text-gray-700 placeholder-gray-400 text-sm focus:outline-hidden focus:border-blue-500 focus:ring-3 focus:ring-blue-100 transition-all font-sans"
        />
      </div>

      {/* Primary Keywords */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
          <Hash className="w-3.5 h-3.5 text-emerald-500" /> Target keywords (SEO)
        </label>
        <input
          id="keywords-input"
          type="text"
          value={params.keywords}
          onChange={(e) => setParams({ ...params, keywords: e.target.value })}
          placeholder="e.g. remote productivity, travel hacks, kyoto guide"
          className="w-full p-3.5 rounded-xl border border-gray-200 bg-white text-gray-700 placeholder-gray-400 text-sm focus:outline-hidden focus:border-blue-500 focus:ring-3 focus:ring-blue-100 transition-all font-sans"
        />
        <p className="text-xs text-gray-400 mt-1.5 px-1 leading-relaxed">
          Provide comma-separated values. These are injected naturally and evaluated in metrics.
        </p>
      </div>

      {/* Target Audience */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
          <Target className="w-3.5 h-3.5 text-purple-500" /> Target Audience
        </label>
        <input
          id="audience-input"
          type="text"
          value={params.audience}
          onChange={(e) => setParams({ ...params, audience: e.target.value })}
          placeholder="e.g. Young freelancers, corporate managers, budget hikers"
          className="w-full p-3.5 rounded-xl border border-gray-200 bg-white text-gray-700 placeholder-gray-400 text-sm focus:outline-hidden focus:border-blue-500 focus:ring-3 focus:ring-blue-100 transition-all font-sans"
        />
      </div>

      {/* Tone selection */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
          <Type className="w-3.5 h-3.5 text-indigo-500" /> Copy Tone
        </label>
        <select
          id="tone-select"
          value={params.tone}
          onChange={(e) => setParams({ ...params, tone: e.target.value })}
          className="w-full p-3 rounded-xl border border-gray-200 bg-white text-gray-700 text-sm focus:outline-hidden focus:border-blue-500 transition-all font-sans cursor-pointer"
        >
          {TONES.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
      </div>

      {/* Purpose */}
      <div>
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-orange-500" /> Primary Marketing Goal
        </label>
        <select
          id="purpose-select"
          value={params.purpose}
          onChange={(e) => setParams({ ...params, purpose: e.target.value })}
          className="w-full p-3 rounded-xl border border-gray-200 bg-white text-gray-700 text-sm focus:outline-hidden focus:border-blue-500 transition-all font-sans cursor-pointer"
        >
          {PURPOSES.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
      </div>

      {/* Language / Length inline row */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-sky-500" /> Language
          </label>
          <select
            id="language-select"
            value={params.language}
            onChange={(e) => setParams({ ...params, language: e.target.value })}
            className="w-full p-3 rounded-xl border border-gray-200 bg-white text-gray-700 text-sm focus:outline-hidden focus:border-blue-500 transition-all font-sans cursor-pointer"
          >
            {LANGUAGES.map((l) => (
              <option key={l.value} value={l.value}>
                {l.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest block mb-2 px-1 flex items-center gap-1.1">
            📏 Length
          </label>
          <select
            id="length-select"
            value={params.length}
            onChange={(e) => setParams({ ...params, length: e.target.value })}
            className="w-full p-3 rounded-xl border border-gray-200 bg-white text-gray-700 text-sm focus:outline-hidden focus:border-blue-500 transition-all font-sans cursor-pointer"
          >
            {LENGTHS.map((len) => (
              <option key={len.value} value={len.value}>
                {len.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2.5 mt-2">
        <button
          type="button"
          id="reset-form-btn"
          onClick={handleReset}
          disabled={loading}
          className="px-3.5 py-3 rounded-xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-500 transition-all cursor-pointer disabled:opacity-50"
          title="Reset Parameters"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
        <button
          type="submit"
          id="generate-btn"
          disabled={loading || !params.topic.trim()}
          className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm rounded-xl transition-all shadow-md hover:shadow-lg focus:outline-hidden focus:ring-4 focus:ring-blue-100 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2 cursor-pointer"
        >
          {loading ? (
            <span className="flex items-center gap-2.5">
              <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>Cooking Draft...</span>
            </span>
          ) : (
            <>
              <span>Draft High SEO Copy</span>
              <ChevronRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </form>
  );
}
