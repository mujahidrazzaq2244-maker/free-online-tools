/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { HistoryItem } from "../types";
import { History, FileText, Trash2, ArrowRight } from "lucide-react";

interface HistorySidebarProps {
  history: HistoryItem[];
  activeId: string | null;
  onSelect: (item: HistoryItem) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

export default function HistorySidebar({
  history,
  activeId,
  onSelect,
  onDelete,
  onClearAll,
}: HistorySidebarProps) {
  if (history.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-gray-150 p-6 text-center shadow-xs">
        <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center mx-auto mb-3">
          <History className="w-5 h-5 text-gray-400" />
        </div>
        <h4 className="text-sm font-bold text-gray-700">Archived Workspace Drafts</h4>
        <p className="text-xs text-gray-400 mt-1 leading-relaxed max-w-[200px] mx-auto">
          Start generating SEO-friendly WordPress content to build local backup files here.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-150 overflow-hidden shadow-xs" id="history-sidebar">
      {/* Title Header list */}
      <div className="px-4 py-3 bg-gray-50/50 border-b border-gray-100 flex items-center justify-between">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
          <History className="w-3.5 h-3.5 text-blue-500" /> Workspace History ({history.length})
        </span>
        <button
          onClick={onClearAll}
          id="clear-history-btn"
          className="text-[10px] text-red-500 hover:text-red-700 font-semibold cursor-pointer transition-all"
        >
          Clear All
        </button>
      </div>

      {/* History scroll list */}
      <div className="p-2.5 max-h-[300px] overflow-y-auto space-y-1.5 scrollbar-thin">
        {history.map((item) => {
          const isActive = item.id === activeId;
          const formattedTime = new Date(item.timestamp).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          });

          return (
            <div
              key={item.id}
              id={`history-item-${item.id}`}
              className={`p-2.5 rounded-xl border transition-all flex items-start justify-between gap-2 group cursor-pointer ${
                isActive
                  ? "bg-blue-50/40 border-blue-200"
                  : "border-transparent hover:bg-gray-50 hover:border-gray-150"
              }`}
              onClick={() => onSelect(item)}
            >
              <div className="flex gap-2.5 max-w-[80%]">
                <div className={`p-1.5 h-8 w-8 rounded-lg shrink-0 flex items-center justify-center ${
                  isActive ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-500"
                }`}>
                  <FileText className="w-4 h-4" />
                </div>

                <div className="space-y-0.5 min-w-0">
                  <h4 className={`text-xs font-bold truncate ${isActive ? "text-blue-900 font-bold" : "text-gray-700"}`}>
                    {item.result.title || "Untitled Draft"}
                  </h4>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-sans">
                    <span className="capitalize">{item.params.contentType}</span>
                    <span>•</span>
                    <span>{formattedTime}</span>
                  </div>
                </div>
              </div>

              {/* Trash/Load buttons */}
              <button
                id={`delete-history-${item.id}`}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(item.id);
                }}
                className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 p-1 rounded-md transition-all cursor-pointer"
                title="Delete Draft"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
