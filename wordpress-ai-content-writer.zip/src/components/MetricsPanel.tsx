/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { SEOMetrics } from "../utils";
import { 
  Award, 
  Clock, 
  Bookmark, 
  CheckCircle, 
  AlertCircle, 
  ArrowRight,
  TrendingUp,
  BookmarkCheck
} from "lucide-react";

interface MetricsPanelProps {
  metrics: SEOMetrics;
}

export default function MetricsPanel({ metrics }: MetricsPanelProps) {
  const { wordCount, charCount, readingTime, keywordMatches, seoScore, checklist } = metrics;

  // Score color helper
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (score >= 50) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-red-600 bg-red-50 border-red-100";
  };

  const getScoreProgressColor = (score: number) => {
    if (score >= 80) return "stroke-emerald-500";
    if (score >= 50) return "stroke-amber-500";
    return "stroke-red-500";
  };

  return (
    <div className="space-y-6" id="metrics-panel">
      {/* 1. SEO Gauge Header card */}
      <div className={`p-4 rounded-2xl border flex items-center gap-4 ${getScoreColor(seoScore)}`}>
        {/* Radial Progress SVG */}
        <div className="relative w-16 h-16 shrink-0 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="32"
              cy="32"
              r="28"
              className="stroke-gray-200 fill-none"
              strokeWidth="4"
            />
            <circle
              cx="32"
              cy="32"
              r="28"
              className={`fill-none transition-all duration-500 ${getScoreProgressColor(seoScore)}`}
              strokeWidth="4.5"
              strokeDasharray={`${2 * Math.PI * 28}`}
              strokeDashoffset={`${2 * Math.PI * 28 * (1 - seoScore / 100)}`}
              strokeLinecap="round"
            />
          </svg>
          <span className="absolute text-sm font-bold font-sans">{seoScore}%</span>
        </div>

        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-gray-450 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5" /> YOAST AUDIT SCORE
          </div>
          <p className="text-sm font-bold text-gray-800">
            {seoScore >= 80 ? "SEO Optimized & Ready!" : seoScore >= 50 ? "Almost Ready - Perfect It" : "Needs Key Revisions"}
          </p>
          <p className="text-[11px] text-gray-500 font-sans leading-normal">
            {seoScore >= 80 
              ? "All critical semantic guidelines met. Ideal keyword weighting & readability."
              : "Increase target density and tweak titles to approach 100% search compatibility."
            }
          </p>
        </div>
      </div>

      {/* 2. Text Dynamics Metrics Row (Bento/Card styles) */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl text-center">
          <span className="text-xs font-semibold text-gray-400 block mb-0.5">Word Count</span>
          <span className="text-sm font-bold text-gray-800 font-mono">{wordCount}</span>
        </div>
        <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl text-center">
          <span className="text-xs font-semibold text-gray-400 block mb-0.5">Character</span>
          <span className="text-sm font-bold text-gray-800 font-mono">{charCount}</span>
        </div>
        <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl text-center flex flex-col justify-center items-center">
          <span className="text-xs font-semibold text-gray-400 block mb-0.5 flex items-center gap-1">
            <Clock className="w-3 h-3" /> Read
          </span>
          <span className="text-sm font-bold text-gray-800 font-mono">{readingTime} min</span>
        </div>
      </div>

      {/* 3. Keyword Density Weights */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 space-y-3 shadow-xs">
        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-blue-500" /> Target Keyword Placement
        </h4>
        
        {keywordMatches.length > 0 ? (
          <div className="space-y-2">
            {keywordMatches.map((kw, idx) => {
              const count = kw.count;
              let badgeStyle = "bg-red-50 text-red-700 border-red-100";
              let label = "Missing";
              
              if (count >= 3) {
                badgeStyle = "bg-emerald-50 text-emerald-700 border-emerald-100";
                label = "Perfect (3x+)";
              } else if (count > 0) {
                badgeStyle = "bg-amber-50 text-amber-700 border-amber-100";
                label = "Low (1-2x)";
              }

              return (
                <div 
                  key={kw.keyword + idx}
                  className="p-2.5 rounded-lg border border-gray-100 flex items-center justify-between text-xs"
                >
                  <span className="font-semibold text-gray-700 font-sans max-w-[120px] truncate" title={kw.keyword}>
                    {kw.keyword}
                  </span>
                  
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-gray-500">Found: {count}x</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md border ${badgeStyle}`}>
                      {label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-3 bg-gray-50 rounded-lg text-xs text-gray-400 italic text-center leading-normal">
            Add target keywords in your configurations to dynamically compute density indicators inside the draft!
          </div>
        )}
      </div>

      {/* 4. Semantic Audits Checklists */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wide px-1 flex items-center gap-1.5">
          <BookmarkCheck className="w-3.5 h-3.5 text-blue-500" /> SEO Checklist Audits
        </h4>

        <div className="space-y-2">
          {checklist.map((item) => (
            <div 
              key={item.id}
              className={`p-3 bg-white border rounded-xl flex items-start gap-3 shadow-2xs transition-all ${
                item.passed ? "border-gray-150" : "border-amber-100 bg-amber-50/10"
              }`}
            >
              <span className="shrink-0 mt-0.5">
                {item.passed ? (
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-500" />
                )}
              </span>

              <div className="space-y-0.5">
                <span className={`text-xs font-bold font-sans ${item.passed ? "text-gray-700" : "text-gray-700"}`}>
                  {item.label}
                </span>
                {!item.passed && (
                  <p className="text-[11px] text-amber-600 font-sans leading-relaxed">
                    👉 {item.tip}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
