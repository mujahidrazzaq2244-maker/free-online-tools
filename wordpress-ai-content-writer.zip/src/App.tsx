/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { GeneratorParams, GeneratedContent, HistoryItem } from "./types";
import { calculateMetrics, parseKeywords } from "./utils";
import SidebarForm from "./components/SidebarForm";
import EditorSimulator from "./components/EditorSimulator";
import MetricsPanel from "./components/MetricsPanel";
import HistorySidebar from "./components/HistorySidebar";
import { 
  Sparkles, 
  HelpCircle, 
  BookOpen, 
  FileCheck, 
  AlertTriangle, 
  Settings, 
  Wrench,
  CheckCircle,
  Lightbulb,
  CornerDownRight,
  TrendingUp
} from "lucide-react";

// Onboarding seed draft content
const SEED_RESULT: GeneratedContent = {
  title: "10 Essential Gutenberg Hacks for Modern WordPress Editors",
  content: `## 1. Introduction: Supercharging Your WordPress Blog
As a modern digital publisher or blogger, writing high-quality text is only half the battle. How you present your ideas inside the WordPress Gutenberg Block Editor dictates reader dwell times, conversion rates, and SEO visibility. 

In this comprehensive guide, we unpack 10 essential tips to streamline your workflow and keep your audience highly engaged.

## 2. Speed Up Setup with Keyboard Shortcuts (/)
Instead of scrolling through the endless block directory to find headings or media tabs, simply type a forward slash (\`/\`) followed by the block identifier. 
* Press \`Shift + Alt + Z\` to toggle the block breadcrumbs
* Type \`/image\`, \`/columns\`, or \`/gallery\` to insert blocks instantly
* Use keyboard triggers to create seamless block nesting

Using keyboard combinations transforms Gutenberg from a slow dragging system into an efficient writer's canvas.

## 3. Leverage Block Reusability for Custom CTAs
Do you find yourself manually styling standard call-to-action boxes, author bios, or email opt-in headers for every new post? Save them as **Custom Reusable Blocks (Synced Patterns)**. 
Once defined, any change to a reusable block propagates instantly to all published pages across your database. This is a gamechanger for promotional launches and quick updates.

## 4. Optimize Layout Readability using Column Blocks
Avoid presenting massive, intimidating screens of flat text. Break up paragraphs into clean 50/50 side-by-side columns to present complex comparison stats, pros vs cons checklists, or feature parameters visually. Keep sentences short and readable—aiming for 2 to 3 sentences max per paragraph block.`,
  metaDescription: "Discover 10 must-know WordPress Gutenberg hacks to speed up your article composition, streamline page layout styling, and increase reader dwell times.",
  tags: ["wordpress", "gutenberg", "seo writing", "blogging tips", "content marketing"],
  callToAction: "Download Your Ultimate 100-Point WordPress SEO Checklist Free!"
};

const SEED_PARAMS: GeneratorParams = {
  contentType: "Blog Post",
  topic: "10 Essential Gutenberg Hacks for Modern WordPress Editors",
  keywords: "wordpress, gutenberg, seo writing",
  audience: "WordPress Bloggers and Digital Publishers",
  tone: "Friendly & Conversational",
  purpose: "Increase SEO Organic Rankings",
  language: "English",
  length: "Medium (~1000 words)"
};

export default function App() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [activeHistoryId, setActiveHistoryId] = useState<string | null>(null);
  
  // Workspace active values
  const [params, setParams] = useState<GeneratorParams>(SEED_PARAMS);
  const [result, setResult] = useState<GeneratedContent>(SEED_RESULT);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showGuide, setShowGuide] = useState(true);

  // WordPress interactive publisher simulation states
  const [publishing, setPublishing] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState(false);

  const handlePublishClick = () => {
    setPublishing(true);
    setPublishSuccess(false);
    setTimeout(() => {
      setPublishing(false);
      setPublishSuccess(true);
      setTimeout(() => {
        setPublishSuccess(false);
      }, 5000);
    }, 1200);
  };

  // Load history from LocalStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("wp_content_history");
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setHistory(parsed);
          // Set the first item active initially or stay on seed
        }
      }
    } catch (err) {
      console.error("Failed to load history:", err);
    }
  }, []);

  // Save history to LocalStorage helper
  const saveHistory = (newHistory: HistoryItem[]) => {
    setHistory(newHistory);
    try {
      localStorage.setItem("wp_content_history", JSON.stringify(newHistory));
    } catch (err) {
      console.error("Failed to save history:", err);
    }
  };

  // Generate action calling backend API
  const handleGenerate = async (submittedParams: GeneratorParams) => {
    setLoading(true);
    setError(null);
    setParams(submittedParams);

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(submittedParams),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Server responded with status code: ${response.status}`);
      }

      const generated: GeneratedContent = await response.json();
      
      // Update result state
      setResult(generated);
      setActiveHistoryId(null);

      // Save to history list
      const newItem: HistoryItem = {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toISOString(),
        params: submittedParams,
        result: generated
      };
      
      saveHistory([newItem, ...history].slice(0, 30)); // Maintain past 30 items
      setActiveHistoryId(newItem.id);

    } catch (err: any) {
      console.error("Generation error:", err);
      setError(
        err.message || 
        "Failed to bridge secure Gemini request. Please check that you entered your GEMINI_API_KEY inside the Secrets panel."
      );
    } finally {
      setLoading(false);
    }
  };

  // Selection from workspace history
  const handleSelectHistoryItem = (item: HistoryItem) => {
    setParams(item.params);
    setResult(item.result);
    setActiveHistoryId(item.id);
    setError(null);
  };

  // Deletion from history
  const handleDeleteHistoryItem = (id: string) => {
    const nextHistory = history.filter((item) => item.id !== id);
    saveHistory(nextHistory);
    if (activeHistoryId === id) {
      setActiveHistoryId(null);
    }
  };

  // Clear entire history
  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear your local workspace history? This is irreversible.")) {
      saveHistory([]);
      setActiveHistoryId(null);
    }
  };

  // Real-time edited results sync back to compute metrics dynamically
  const handleEditorChange = (updatedResult: GeneratedContent) => {
    setResult(updatedResult);
    
    // Also sync to active history item to avoid losing edits
    if (activeHistoryId) {
      const updatedHistory = history.map((item) => {
        if (item.id === activeHistoryId) {
          return { ...item, result: updatedResult };
        }
        return item;
      });
      saveHistory(updatedHistory);
    }
  };

  // Compute live metrics dynamically based on current title & body edits!
  const targetKeywordsList = parseKeywords(params.keywords);
  const liveMetrics = calculateMetrics(
    result.title,
    result.content,
    result.metaDescription,
    targetKeywordsList
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-gray-800" id="main-view">
      
      {/* PROFESSIONAL DASHBOARD HEADER */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-xs px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-200">
            <span className="text-xl font-black font-sans">W</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-gray-900 tracking-tight font-sans">
                WordPress AI Content Writer
              </h1>
              <span className="px-2 py-0.5 text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-100 rounded-md uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 fill-current" /> Gemini 3.5
              </span>
            </div>
            <p className="text-xs text-gray-500 font-sans">
              Dynamic Digital Planner Workspace &bull; Pro-grade search grounding audits
            </p>
          </div>
        </div>

        {/* Quick Help Tabs */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-gray-400 bg-gray-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Workspace Connected
          </span>
          <button
            onClick={() => setShowGuide(!showGuide)}
            id="toggle-guide-btn"
            className="p-2 text-gray-500 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
          >
            <HelpCircle className="w-4 h-4 text-blue-500" />
            <span>SEO Tips</span>
          </button>
        </div>
      </header>

      {/* QUICK METADATA PASTE GUIDE / NOTIFICATION BANNER */}
      {showGuide && (
        <div className="bg-gradient-to-tr from-blue-700 via-indigo-800 to-indigo-900 text-white px-6 py-5 border-b border-indigo-950 transition-all text-sm shadow-xs relative" id="guide-banner">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4 pr-8">
            <div className="space-y-1.5 max-w-4xl">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4.5 h-4.5 text-yellow-400 font-bold fill-current" />
                <span className="font-extrabold text-sm uppercase tracking-wider">WordPress Copy-Paste Formatting Guide</span>
              </div>
              <p className="text-xs text-indigo-150 leading-relaxed font-sans">
                Save manual editing hours with this tool. Design and audit drafts here, then export straight to WordPress. Keep descriptions between **150–160 characters** for search snippet health, insert **subheadings (H2, H3)** to capture featured listings, and map exact generated tags as WordPress taxonomies to group archives gracefully!
              </p>
            </div>
            <div className="flex gap-4 self-start md:self-center shrink-0">
              <div className="text-xs border border-indigo-500/30 bg-indigo-900/50 rounded-xl px-3 py-2 text-indigo-100 flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <span>100% Plagiarism Free</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowGuide(false)}
            id="dismiss-guide-btn"
            className="absolute top-4 right-4 text-indigo-200 hover:text-white transition-all cursor-pointer font-bold text-lg"
            title="Dismiss Guide"
          >
            &times;
          </button>
        </div>
      )}

      {/* ERROR HANDLER CARD */}
      {error && (
        <div className="mx-6 mt-6 p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3.5 text-sm shadow-xs" id="error-card">
          <span className="p-1 rounded-lg bg-red-100 text-red-700 mt-0.5 shrink-0">
            <AlertTriangle className="w-4.5 h-4.5" />
          </span>
          <div className="space-y-1">
            <strong className="text-red-900 block font-bold font-sans">Gemini API Bridge Exception</strong>
            <p className="text-red-700 leading-relaxed font-sans text-xs">
              {error}
            </p>
            <div className="pt-2 text-xs text-gray-500 flex flex-wrap gap-2 items-center leading-normal">
              <span>🔧 To configure: Go back to the top-right AI Studio interface selection</span>
              <CornerDownRight className="w-3.5 h-3.5" />
              <span className="font-semibold text-gray-700 bg-gray-200/50 px-1.5 py-0.5 rounded-sm">Settings</span>
              <span>&gt;</span>
              <span className="font-semibold text-gray-700 bg-gray-200/50 px-1.5 py-0.5 rounded-sm">Secrets</span>
              <span>and enter your Gemini API key value.</span>
            </div>
          </div>
        </div>
      )}

      {/* THREE-COLUMN BENTO GRID MAIN WORKSPACE OUTLINE */}
      <main className="flex-1 w-full max-w-[1600px] mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* COLUMN 1: CONFIGURATION & HISTORY CONTROLS (XS TO LG: 12, LARGE: 3.5) */}
        <section className="lg:col-span-3.5 space-y-6">
          <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4 border-b border-gray-100 pb-3">
              <h3 className="text-sm font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
                <Settings className="w-4.5 h-4.5 text-blue-600" /> Digital Copy parameters
              </h3>
              <span className="text-[10px] bg-slate-100 text-slate-500 font-bold px-2 py-0.5 rounded-sm tracking-wide">
                STEP 1
              </span>
            </div>

            {/* Parameter selection input form */}
            <SidebarForm 
              onGenerate={handleGenerate} 
              loading={loading} 
              initialParams={params}
            />
          </div>

          {/* Past Generated drafts histories */}
          <HistorySidebar
            history={history}
            activeId={activeHistoryId}
            onSelect={handleSelectHistoryItem}
            onDelete={handleDeleteHistoryItem}
            onClearAll={handleClearHistory}
          />
        </section>

        {/* COLUMN 2: INTERACTIVE PUBLISHING SIMULATOR VIEW (LG: 5.5) */}
        <section className="lg:col-span-5.5 flex flex-col h-full gap-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-blue-500" /> Workspace Editor & Previewer
            </span>
            <span className="text-xs text-gray-450 italic font-medium flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-emerald-500 animate-pulse" /> Auto-Backed Up
            </span>
          </div>

          {/* Beautiful interactive editor simulator */}
          <EditorSimulator 
            result={result} 
            onChange={handleEditorChange} 
          />
        </section>

        {/* COLUMN 3: SEO AUDITS, KEYWORD DENSITIES, METRIC INDICATORS (LG: 3) */}
        <section className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-blue-500" /> SEO Analytics Dashboard
            </span>
            <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-sm font-bold">
              REAL-TIME
            </span>
          </div>

          <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-xs">
            {/* Compute and present metrics, audits and matches dynamically */}
            <MetricsPanel metrics={liveMetrics} />
          </div>
        </section>

      </main>

      {/* DASHBOARD BOTTOM FOOTER */}
      <footer className="bg-white border-t border-gray-200/65 py-4 text-center mt-auto">
        <p className="text-[11px] text-gray-400 font-sans tracking-wide">
          &bull; WordPress AI Content Writer & Digital Marketing Work Station &bull; Powered securely by Google Gemini &bull; All copy is locally persistent &bull; 
        </p>
      </footer>

    </div>
  );
}
