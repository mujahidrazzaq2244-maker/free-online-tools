import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Setup JSON parsing
app.use(express.json({ limit: "10mb" }));

// Initialize GoogleGenAI securely
let aiClient: GoogleGenAI | null = null;
function getAiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing. Please save it in the Secrets panel inside AI Studio.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// API endpoint to generate content
app.post("/api/generate", async (req, res) => {
  try {
    const {
      contentType,
      topic,
      audience,
      tone,
      purpose,
      keywords,
      language,
      length,
    } = req.body;

    if (!topic || !contentType) {
      return res.status(400).json({ error: "Missing required fields: topic and contentType." });
    }

    const ai = getAiClient();
    
    // Create rich prompts
    const systemInstruction = 
      "You are a professional AI Content Writer and Digital Marketing Expert specialized in WordPress seo-optimized high-conversion content. " +
      "Your goal is to generate extremely engaging, custom, 100% original, and highly readable copy. " +
      "You strictly output the response in the provided JSON schema format.";

    const prompt = `Generate highly optimized, plagiarism-free, engaging WordPress content.
Input Details:
- Content Type: ${contentType}
- Topic: ${topic}
- Target Audience: ${audience || "General Audience"}
- Requested Tone: ${tone || "Friendly and Professional"}
- Purpose: ${purpose || "SEO Visibility & Organic Growth"}
- Keywords to naturally integrate: ${keywords || "N/A"}
- Language: ${language || "English"}
- Desired Length: ${length || "Medium"}

Instructions & Rules:
1. Generate a compelling, high-CTR, SEO-friendly WordPress title.
2. Generate the main body content in Markdown format (use H2, H3 headings, short readable paragraphs of 2-3 sentences, and lists/bullet points as appropriate for the topic and content type).
Wait, do not write the title or H1 inside this main body content, as the title is returned as a separate field.
3. Keep the content structure rich with an engaging hook/introduction and a powerful summary/conclusion.
4. Integrate the requested keywords naturally throughout the copy without keyword stuffing.
5. Keep paragraphs highly readable and compact.
6. The content must be ready to publish directly on a WordPress blog.
7. Generate a professional meta description that is exactly 150 to 160 characters long, incorporating the primary keywords.
8. Brainstorm exactly 5 relevant tags.
9. Construct a highly engaging and relevant Call to Action (CTA) tailored to the target audience and purpose.
10. Ensure the response strictly matches the provided JSON schema structure. Make sure everything is written in ${language || "English"}.`;

    const modelResponse = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.8,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: "The SEO-optimized, engaging title for the WordPress post."
            },
            content: {
              type: Type.STRING,
              description: "The complete body content in formatted Markdown. Do NOT include the main title inside this content."
            },
            metaDescription: {
              type: Type.STRING,
              description: "SEO Meta description, strictly between 150 to 160 characters."
            },
            tags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 5 highly relevant SEO tags/keywords."
            },
            callToAction: {
              type: Type.STRING,
              description: "A highly engaging, customizable call-to-action block."
            }
          },
          required: ["title", "content", "metaDescription", "tags", "callToAction"]
        }
      }
    });

    if (!modelResponse.text) {
      throw new Error("Zero response text received from the Gemini model.");
    }

    const resultJson = JSON.parse(modelResponse.text.trim());
    return res.json(resultJson);

  } catch (error: any) {
    console.error("Error generating content:", error);
    return res.status(500).json({
      error: error.message || "An unexpected error occurred while generating content.",
    });
  }
});

async function startServer() {
  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
